package io.conduktor.demos.kafka;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class ProducerDemo {
    private static final Logger log= LoggerFactory.getLogger(ProducerDemo.class.getSimpleName());
    public static void main(String[] args) throws InterruptedException {
        log.info("HELLO WORLD");
        Properties properties;
        properties=new Properties();
        ((Properties) properties).setProperty("bootstrap.servers","cluster.playground.cdkt.io:9092");
        ((Properties) properties).setProperty("security.protocol","SASL_SSL");
        ((Properties) properties).setProperty("sasl.jaas.config","org.apache.kafka.common.security.plain.PlainLoginModule required username=\"3QqgThkB7Pwy7fDJxrJeAT\" password=\"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2F1dGguY29uZHVrdG9yLmlvIiwic291cmNlQXBwbGljYXRpb24iOiJhZG1pbiIsInVzZXJNYWlsIjpudWxsLCJwYXlsb2FkIjp7InZhbGlkRm9yVXNlcm5hbWUiOiIzUXFnVGhrQjdQd3k3ZkRKeHJKZUFUIiwib3JnYW5pemF0aW9uSWQiOjczOTc1LCJ1c2VySWQiOjg2MDMxLCJmb3JFeHBpcmF0aW9uQ2hlY2siOiJjMjUwYmQxYS1mNDM4LTQ3MjUtYmFlNC1jZGEyMDg5ODM3YWYifX0.vrB4xv9DFHIn7YxDN6_hwKWpizrubWTr9VA9322KfgA\";");
        ((Properties) properties).setProperty("sasl.mechanism","PLAIN");
        ((Properties) properties).setProperty("key.serializer", StringSerializer.class.getName());
        ((Properties) properties).setProperty("value.serializer", StringSerializer.class.getName());
        //((Properties) properties).setProperty("partitioner.class","RoundRobinPartitioner.class.getName()");
        KafkaProducer<String,String>producer=new KafkaProducer<>(properties);
        for(int j=0;j<20;j++)
        {
            for(int i=0;i<10;i++) {
                ProducerRecord<String, String> producerRecord = new ProducerRecord<>("java1", "helloworld" + i);
                producer.send(producerRecord, new Callback() {
                    @Override
                    public void onCompletion(RecordMetadata metadata, Exception e) {
                        if (e == null) {
                            log.info("received new metadata\n" + "topic:" + metadata.topic() + "\n" + "partition:" + metadata.partition() + "\n" + "timestamps:" + metadata.timestamp() + "\n" + "offsets:" + metadata.offset());
                        } else {
                            log.error("error", e);
                        }
                    }
                });
            }
            try {
                Thread.sleep(400);
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }

        producer.flush();
        producer.close();




    }

}
